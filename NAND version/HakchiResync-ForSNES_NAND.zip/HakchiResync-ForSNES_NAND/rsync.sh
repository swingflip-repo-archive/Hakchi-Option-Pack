#!/bin/sh

rsync

#rather fitting ain't it?